/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bonus_rush.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgirao-m <rgirao-m@student.42lisboa.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 22:30:27 by rgirao-m          #+#    #+#             */
/*   Updated: 2024/01/27 22:56:24 by rgirao-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush03.h"

void	rush00(int x, int y)
{
	char	characters[6];

	characters[0] = 'o';
	characters[1] = 'o';
	characters[2] = 'o';
	characters[3] = 'o';
	characters[4] = '-';
	characters[5] = '|';
	generic_rush(x, y, characters);
}

void	rush01(int x, int y)
{
	char	characters[6];

	characters[0] = '/';
	characters[1] = '\\';
	characters[2] = '\\';
	characters[3] = '/';
	characters[4] = '*';
	characters[5] = '*';
	generic_rush(x, y, characters);
}

void	rush02(int x, int y)
{
	char	characters[6];

	characters[0] = 'A';
	characters[1] = 'A';
	characters[2] = 'C';
	characters[3] = 'C';
	characters[4] = 'B';
	characters[5] = 'B';
	generic_rush(x, y, characters);
}

void	rush04(int x, int y)
{
	char	characters[6];

	characters[0] = 'A';
	characters[1] = 'C';
	characters[2] = 'C';
	characters[3] = 'A';
	characters[4] = 'B';
	characters[5] = 'B';
	generic_rush(x, y, characters);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgirao-m <rgirao-m@student.42lisboa.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 21:25:13 by rgirao-m          #+#    #+#             */
/*   Updated: 2024/01/27 21:26:19 by rgirao-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	print_line(int x, char left, char middle, char right);

void	print_column(int y, char top, char middle, char bottom);

void	print_rectangle(int x, int y, char characters[]);

void	generic_rush(int x, int y, char characters[]);

void	rush(int x, int y);

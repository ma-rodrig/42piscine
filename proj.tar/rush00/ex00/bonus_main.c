/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bonus_main.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgirao-m <rgirao-m@student.42lisboa.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 22:39:00 by rgirao-m          #+#    #+#             */
/*   Updated: 2024/01/28 09:45:34 by rgirao-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bonus_rush.h"
#include "rush03.h"

int	parse_int(char *str)
{
	int	result;
	int	idx;

	result = 0;
	idx = 0;
	while (str[idx] != '\0')
	{
		if (str[idx] < '0' || str[idx] > '9')
		{
			return (0);
		}
		result = result * 10 + (str[idx] - '0');
		idx++;
	}
	return (result);
}

void	choose_rush(int x, int y, int rush_id)
{
	if (rush_id == 0)
	{
		rush00(x, y);
	}
	else if (rush_id == 1)
	{
		rush01(x, y);
	}
	else if (rush_id == 2)
	{
		rush02(x, y);
	}
	else if (rush_id == 3)
	{
		rush(x, y);
	}
	else if (rush_id == 4)
	{
		rush04(x, y);
	}
}

/*
 * Run the general program.
 *
 * Without arguments, defaults to rush(5, 3).
 *
 * With 2 arguments, defaults to our subject with the given dimensions.
 * E.g., ./main 5 3 will print a 5 x 3 rectangle.
 *
 * With 3 arguments, uses the chosen rush project.
 * E.g., ./main 12 8 4 prints a 12 x 8 rectangle from subject 04.
 *
 * With any other number of arguments, it does nothing.
 * Numeric arguments are expected to be within their valid ranges.
 * (Positive numbers for the dimensions and 0 - 4 for the rush id.)
 * Other values will do nothing.
 */
int	main(int argc, char *argv[])
{
	if (argc == 1)
	{
		rush(5, 3);
	}
	else if (argc == 3)
	{
		rush(parse_int(argv[1]), parse_int(argv[2]));
	}
	else if (argc == 4)
	{
		choose_rush(parse_int(argv[1]), parse_int(argv[2]), parse_int(argv[3]));
	}
}

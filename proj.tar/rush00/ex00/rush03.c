/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rgirao-m <rgirao-m@student.42lisboa.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 21:15:59 by rgirao-m          #+#    #+#             */
/*   Updated: 2024/01/28 11:14:57 by fferrao-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_putchar.h"

void	print_line(int x, char left, char middle, char right)
{
	int	comprimento;

	comprimento = 0;
	while (comprimento != x)
	{
		if (comprimento == 0)
		{
			ft_putchar(left);
		}
		if (comprimento == (x - 1))
		{
			ft_putchar(right);
		}
		if (comprimento > 0 && comprimento < (x - 1))
		{
			ft_putchar(middle);
		}
		comprimento++ ;
	}
	ft_putchar('\n');
}

void	print_column(int y, char top, char middle, char bottom)
{
	int	altura;

	altura = y;
	while (y != 0)
	{
		if (altura == y)
		{
			ft_putchar(top);
		}
		else if (y > 1)
		{
			ft_putchar(middle);
		}
		else
		{
			ft_putchar(bottom);
		}
		ft_putchar('\n');
		--y;
	}
}

void	print_rectangle(int x, int y, char characters[])
{
	int	altura;

	altura = y;
	while (y != 0)
	{
		if (altura == y)
		{
			print_line(x, characters[0], characters[4], characters[1]);
		}
		else if (y > 1)
		{
			print_line(x, characters[5], ' ', characters[5]);
		}
		else
		{
			print_line(x, characters[2], characters[4], characters[3]);
		}
		--y;
	}
}

/*
 * The 6-item array contains the characters used
 * when printing the patterns:
 * 0: top-left corner
 * 1: top-right corner
 * 2: bot-left corner
 * 3: bot-right corner
 * 4: top/bot edges
 * 5: left/right edges
 */
void	generic_rush(int x, int y, char characters[])
{
	if (x <= 0 || y <= 0)
	{
		return ;
	}
	else if (x == 1 && y == 1)
	{
		ft_putchar(characters[0]);
		ft_putchar('\n');
	}
	else if (x == 1)
	{
		print_column(y, characters[0], characters[5], characters[2]);
	}
	else if (y == 1)
	{
		print_line(x, characters[0], characters[4], characters[1]);
	}
	else
	{
		print_rectangle(x, y, characters);
	}
}

void	rush(int x, int y)
{
	char	rush03_characters[6];

	rush03_characters[0] = 'A';
	rush03_characters[1] = 'C';
	rush03_characters[2] = 'A';
	rush03_characters[3] = 'C';
	rush03_characters[4] = 'B';
	rush03_characters[5] = 'B';
	generic_rush(x, y, rush03_characters);
}
